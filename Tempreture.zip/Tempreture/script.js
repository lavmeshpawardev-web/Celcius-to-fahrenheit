const input = document.getElementById("celsius");
const button = document.getElementById("convertBtn");
const result = document.getElementById("result");

button.addEventListener("click", convertTemperature);

function convertTemperature() {

    const celsius = Number(input.value);

    const fahrenheit = (celsius * 9 / 5) + 32;

    result.textContent = fahrenheit + " °F";

}

